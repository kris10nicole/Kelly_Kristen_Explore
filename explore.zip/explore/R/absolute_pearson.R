#' Absolute Pearson Function
#'
#' This function takes a dataframe, consisting of pearson correlations with 2 variables, and extracts the values that are greater than a threshold based on the user's input
#' @param v.
#' @keywords x
#' @export
#' @examples
#' absolute_pearson()#Our ouput is the combination of column names and their Pearson coefficient values that are greater than a specified threshold
absolute_pearson <-function(dataset, threshold)
{
  row_index <- which(abs(dataset[,2]) > threshold)
  return(dataset[row_index, ])
} 
#' Calculate Rsquare Function
#'
#' This function takes a dataframe and determines the R-square values of each of the variables
#' @param v.
#' @keywords x
#' @export
#' @examples
#' Calculate_Rsquare()#Our ouput is the combination of column names and their respective R-square values
Calculate_Rsquare<- function(data)
{
  Numeric <-sapply(data, is.numeric)
  ExploreData <-data[,Numeric]
  Names <-ColumnNames(ExploreData)
  ComboNames <-combn(Names, 2)
  Combo <-combn(length(ColumnNames(ExploreData)), 2)
  a <-paste(ComboNames[1,], ComboNames[2,], sep = '-')
  Rsquare <- c()
  
  for(i in 1:length(a)){                       
    Regression <-paste0(ComboNames[1,i], " ~ ", ComboNames[2,i])
    r1 <- summary( lm(as.formula(Regression), data=ExploreData) )$r.squared
    Rsquare[i] <- r1                                          
  }
  return(data.frame(a, Rsquare))
}
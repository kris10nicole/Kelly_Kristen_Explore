#' Frequency Table Function
#'
#' This function allows you create a frequency table from a dataframe
#' @param v.
#' @keywords x
#' @export
#' @examples
#' freq_table()#Our input is a dataframe; our output is a factor class table
freq_table <-function(data) 
{
  lapply(data[, sapply(data,is.factor)], table)   
}

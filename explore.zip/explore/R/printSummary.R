#' PintSummary
#'
#' This function prints out a summary table for a given dataframe
#' @param v.
#' @keywords x
#' @export
#' @examples
#' printSummary()#Our input is a dataframe; our output is a summary table
printSummary <-function(data)
{
  lapply(data[, sapply(data,is.numeric)], summary)
}
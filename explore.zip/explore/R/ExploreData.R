#' Explore Data Function
#'
#' This function combines all the previous functions and allows prints a frequency table of categorical variables, a summary table for numerical variables, an R-square table for each numerical variable, a Pearson table for each numerical variable, a count and density histogram for each numerical variable with user input, and a bar graph for each categorical or logical variable
#' @param v.
#' @keywords x
#' @export
#' @examples
#' ExploreData()
ExploreData <- function(dataframe, Plot_Switch, threshold, binVec){
  
  while(!is.data.frame(dataframe)){                 #Here we want to check to see if the user inputs a dataframe. If he/she does not, we prompt the user to choose a new file, which will be converted to a dataframe
    print("Your input is not a dataframe: ")
    print("Please upload a new csv or text file: ")
    file1 <- file.choose()
    dataframe <- read.csv(file1, header = T)
  }
  
  Button <- plot_switch
  while(button != "off" && button != "on" && button != "grid"){   #Here we check to see if Plot_Switch is valid input
    print("This is an invalid input for the plot switch. Try again.")
    n <- readline(prompt="Enter your option(off / on / grid): ")  #Here we have the user re-enter the input
    button <- n
  }
  
  threshold2 <- threshold
  while(!is.numeric(threshold2) || threshold2 < 0 || threshold2 >1 ){    #Here we check to see if the threshold is a valid input
    print("The correlation threshold must be numeric value within the interval [0,1]. Try again.")
    a <- readline(prompt="Enter your correlation threshold: ")      #Here we have the user re-enter the threshold input
    threshold <- as.numeric(a)
  }
  
  while (!missing(binVec) && TRUE %in% (binVec <= 0)) {                        #Here we check to see if the bins are positive; if they are not, we prompt the user to input them again
    a <- readline(prompt="Enter a size of the bin Vector (or enter e to end): ")
    if(a == "e"){
      stop("End")
    }
    else{
      binVec <- c()
      size <- as.numeric(a)
      for(i in 1:size){
        bin <- readline(prompt="Enter the number of bins: ")
        bin <- as.numeric(bin)
        binVec <- c(binVec, bin)
      }
    }
    
  }
  
  if (!missing(binVec) && !is.integer(binVec)) {            #Here we check to see if the bins are integers; if they are not, then we round them 
    binVec <- round(binVec)
  }
  
  
  New_Dataframe <- freq_table(dataframe)
  allSummary <- printSummary(dataframe)
  Coefficient_Table <- pearson(dataframe)
  Absolute_Coefficient_Table <-absolute_pearson(Coefficient_Table, threshold2)
  Rsquare_Table <- Calculate_Rsquare(dataframe)
  Numeric_Plot(dataframe, button, binVec)
  Categorical_Binary_Plot(dataframe, button)
  New_List <-list(new_dataframe, allSummary, Rsquare_Table, Absolute_Coefficient_Table)
  return(New_List)
  
}
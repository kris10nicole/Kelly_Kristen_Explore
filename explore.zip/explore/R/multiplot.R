#' Multiplot Function
#'
#' This function combines subplots plots into a grid and prints out the data
#' @param v.
#' @keywords x
#' @export
#' @examples
#' multiplot()#Our input is a grid with several plots
multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) 
{
  
  #Here we want to make a list from the ... arguments and plot the list
  plots <-c(list(...), plotlist)
  
  NumberPlots = length(plots)
  
  #If layout is NULL, then we use 'cols' to determine layout
  if (is.null(layout)) {
    #First we make the panel
    layout <- matrix(seq(1, cols * ceiling(NumberPlots/cols)),				#The nCol variable will be the number of columns of plots
                     nCol = cols, nRow = ceiling(NumberPlots/cols))			#The nRow variable will be the number of needed and will be calculated from the number of columns
  }
  
  if (NumberPlots==1) {	#If the number of plots is one, then we only print one plot
    print(plots[[1]])
    
  } else {
    grid.newpage()		#Here we set up the grids of plots on a new page if the number of plots is not one
    pushViewport(viewport(layout = grid.layout(nRow(layout), nCol(layout))))
    
    for (i in 1:numPlots) {		#Here we make sure each plot is in its appropriate location on the page; to do this, we will need to figure out its exact location:
      matchidx <-as.data.frame(which(layout == i, arr.ind = TRUE))
      
      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}
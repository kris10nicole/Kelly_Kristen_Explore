#' Categorical Binary Plot Function
#'
#' This function plots a gray bar graph for every categorical and binary variable if certain conditions are met
#' @param v.
#' @keywords x
#' @export
#' @examples
#' Categorical_Binary_Plot()#Our output are gray bar graphs
Categorical_Binary_Plot <-function(data, Plot_Switch_Parameter){
  Categorical_Binary_Plot <- sapply(data, function(x) (is.factor(x) || is.logical(x)) || is.binary(x))    #Here we check to make sure we have categorical and binary columns
  Categorical_Binary_Plot <- data[Categorical_Binary]     #extract those columns
  
  if(plot_switch == "on" || plot_switch == "grid") {      #Here we check condition for the sring input 
    for(name in ColumNames(Categorical_Binary_Data)) {             #loop through the sorted dataframe and plot bar graphs for each column
      k <-ggplot(Categorical_Binary_Data, aes_string(name), color = "grey") + geom_bar(fill="grey")
      print(k)
    }
  }
}
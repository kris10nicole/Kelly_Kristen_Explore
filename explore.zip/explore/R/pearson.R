#' Pearson Function
#'
#' This function takes any dataframe as a parameter and returns a dataframe that contains each pair of column names in the first column as a single string seperated by a "-" and their corresponding Pearson correlation coefficient in the second column.
#' @param v.
#' @keywords x
#' @export
#' @examples
#' pearson()#Our ouput is the combination of column names and their Pearson coefficients
pearson<- function(data)
{
  Numeric <-sapply(data, is.numeric)        
  ExploreData <-data[,Numeric]              
  Names <-ColumnNames(ExploreData)
  ComboNames <-combn(Names, 2)
  Combo <- combn(length(ColumnNames(ExploreData)), 2)
  a <-paste(ComboNames[1,],ComboNames[2,],sep = '-')
  pearson <-PearsonCoefficent <- c()
  
  for(i in 1:length(a))
  {
    p <-cor(x= ExploreData[combo[1,i]], y = ExploreData[combo[2,i]])
    PearsonCoefficent[i] <- p[1]
  }
  return(data.frame(a, Pearsoncoefficient))
}
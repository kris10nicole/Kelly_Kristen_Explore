#' Numeric Plot Function
#'
#' This function ot a pair of blue histograms with a vertical red line at the mean if certain conditions are met
#' @param v.
#' @keywords x
#' @export
#' @examples
#' Numeric_Plot()#Our output is a grid with plots containing the count and desnity histograms
Numeric_Plot <- function(data, Plot_Switch, binVec) {
  Numeric <-sapply(data, is.numeric)         #Here we check to see which columns are numeric
  data <-data[,Numeric]                      #Here we extract the numeric columns
  for(name in ColumnNames(data)) {           #Here we will loop through the columns in the dataset
    
    if(Plot_Switch == "on"){                 #Here is the case when the switch is "on"
      grid.newpage()          		   #We put the output on a new page
      r <- lapply(data[name], mean)          # Here we find the mean of that currently iterated column
      plot1 <- ggplot(data, aes_string(name)) + geom_histogram(fill="blue") + geom_vline(xintercept = m[[1]], colour="red") 
      plot2 <- ggplot(data, aes_string(name)) + geom_histogram(aes(y= ..density..), fill="blue") + geom_vline(xintercept = m[[1]], colour="red")
      pushViewport(viewport(layout = grid.layout(1, 2)))
      print(plot1, vp = viewport(layout.pos.row = 1, layout.pos.col = 1))
      print(plot2, vp = viewport(layout.pos.row = 1, layout.pos.col = 2))
    }
    
    if(plot_switch == "grid"){          #Here is the case when switch is "grid"
      Count_Plots <-list()              #Here we create an  empty list to store the count for the histogram subplots of each bin size
      Density_Plots <-list()            #Here we create a empty list to store the density histograms subplots of each bin size
      if(missing(binVec)){              #This takes of the case when the vector is null, prints histogram with default bins 30
        print(ggplot(data, aes_string(name), color = "blue") + geom_histogram(fill="blue")+ labs(title= "default bins"))
        print(ggplot(data, aes_string(name), color = "blue") + geom_histogram(aes(y= ..density..), fill="blue")+ labs(title= "default bins"))
      }else{                            #This takes care of the case when the user enters a vector
        for(i in 1:length(binVec)) {    #loop through each bin size and create a subplot
          z <-ggplot(data, aes_string(name), color = "blue") + geom_histogram(fill="blue", bins = binVec[i])+ labs(title= paste(binVec[i], "bins"))
          count_plots[[i]] <- z           #Push each subplot to a list 
        }
        multiplot(plotlist = count_plots, cols = 2)     
        
        for(i in 1:length(binVec)) {    #Here we loop through each bin size and create a subplot
          z <- ggplot(data, aes_string(name), color = "blue") + geom_histogram(aes(y= ..density..), fill="blue", bins = binVec[i])+ labs(title= paste(binVec[i], "bins"))
          Density_Plots[[i]] <- z       #Here we combine each subplot into a list
        }
        multiplot(plotlist = Density_Plots, cols = 2)
        
      }
    }
  }
}
#' Is Binary Function
#'
#' This function allows you check to see if a value is binary
#' @param v.
#' @keywords x
#' @export
#' @examples
#' is.binary()#Our input is a vector, while our output is True or False (whether or not its binary)
is.binary <-function(v) 
{
  x <-unique(v)  #Here we check to make sure all the elements are unique/distinct and put them in a vector named x
  length(x) - sum(is.na(x)) == 2L  #Here we check to see if x only contains 2 distinct values
}

